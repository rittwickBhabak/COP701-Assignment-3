from setuptools import setup 
setup(name='tkinter', 
version="0.1",
description="Modified Tkinter with a couple of bug fixes and own GraphPlotter",
long_description="Modified Tkinter with a couple of bug fixes and own GraphPlotter made by Rittwick Bhabak from IIT Delhi",
author="Rittwick Bhabak",
packages=['tkinter'],
install_requires=['Pillow==9.2.0'])